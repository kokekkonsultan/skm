@extends('include_template/template')

@php 
	$ci = get_instance();
@endphp

@section('style')

@endsection

@section('content')

@endsection

@section('javascript')

@endsection