@php
$ci = get_instance();
$ci->load->helper('form');
@endphp

<img src="{{ base_url() }}assets/img/site/campaign/bg-bagi-link-wa.jpg" class="img-fluid" alt="">
<br><br>
<div style="color: red; border: 1px red solid; padding: 10px;">
	Features in progress...
</div>