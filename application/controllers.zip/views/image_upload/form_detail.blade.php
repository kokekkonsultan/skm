@php 
	$ci = get_instance();
@endphp

<img src="{{ base_url() }}assets/img/img-upload/{{ $image->image_file_name }}" alt="" class="img-fluid">