@extends('include_backend/template_no_aside')

@php 
	$ci = get_instance();
@endphp

@section('style')

@endsection

@section('content')
<div class="container-fluid">
  

</div>
@endsection

@section('javascript')

@endsection